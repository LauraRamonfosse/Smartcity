import React from "react";
import { useNavigate } from "react-router-dom";

//write a button that modify a line from a table, that recieve the name of the table, the object with the modified data and the id of the line
function ModifyButton({name}) {
  // my name is an 
  const navigate = useNavigate();
  const handleClick = () => {
    navigate(`/${name}/modify`);
  };

  return (
    <>
      <button onClick={handleClick}>
        Modify
      </button>
    </>
  );
}

export default ModifyButton;

