import { useState } from 'react';
import '../../stylesheet/backoffice.css'

function UserForm({type, content}){
    const[username, setUsername] = useState(type === 'modify' ? content.username : '');
    const[password, setPassword] = useState('');
    const[password2, setPassword2] = useState('');
    const[country, setCountry] = useState(type === 'modify' ? content.country : '');  
    const[email, setEmail] = useState(type === 'modify' ? content.email : '');
    const[phone, setPhone] = useState(type === 'modify' ? content.phone : '');
    const[newsletter, setNewsletter] = useState(type === 'modify' ? content.newsletter : false);


// write the handleSubmit function here
    const handleSubmit = (e) => {
        // empty the form
        setUsername('');
        setPassword('');
        setPassword2('');
        setCountry('');
        setEmail('');
        setPhone('');
        setRole('');
        setNewsletter(false);

        e.preventDefault();
        const user = {
            username,
            password,
            password2,
            country,
            email,
            phone,
            role,
            newsletter
        };
        // Show the information in a pop-up window
        alert("The user has been added to the database");
        console.log(user);
    };

    return(
        //write the form here
        <>          
            <form onSubmit={handleSubmit}>
                    <label className="field">Username:
                        <br/>
                        <input 
                        type="text" 
                        name="username"
                        placeholder='Insert...'
                        value={username} onChange={e => setUsername(e.target.value)} />
                    </label>
                    <label className="field">Password:
                        <br/>
                        <input 
                        type="password" 
                        name="password" 
                        placeholder='Insert...'
                        value={password} onChange={e => setPassword(e.target.value)} />
                    </label>
                    <label className="field">Confirm Password:
                        <br/>
                        <input 
                        type="password" 
                        name="password2" 
                        placeholder='Insert...'
                        value={password2} onChange={e => setPassword2(e.target.value)} />
                    </label>
                    <label className="field">Email:
                        <br/>
                        <input 
                        type="email" 
                        name="email"
                        placeholder='Insert...' 
                        value={email} onChange={e => setEmail(e.target.value)} />
                    </label>
                    <label className="field">Country:
                        <br/>
                        <select 
                        name="country" 
                        value={country} onChange={e => setCountry(e.target.value)}>
                            <option value="australia">Australia</option>
                            <option value="canada">Canada</option>
                            <option value="usa">USA</option>
                        </select>
                    </label>
                    <label className="field">Phone:
                        <br/>
                        <input 
                        type="tel" 
                        name="phone" 
                        placeholder='Insert...'
                        value={phone} onChange={e => setPhone(e.target.value)} />
                    </label>
                    <label className="field"> 
                        <input 
                        type="checkbox" 
                        name="newsletter" 
                        checked={newsletter} onChange={e => setNewsletter(e.target.checked)} />
                        Subscribe to Newsletter: 
                    </label>
                    <input type="submit" value="Submit" />
            </form>
                
           
        </>
    );
}
export default UserForm;