import { useState } from 'react';
import '../../stylesheet/backoffice.css'

function BookForm({type, content}){
    const[title, setTitle] = useState(type === 'modify' ? content.title : '');
    const[author, setAuthor] = useState(type === 'modify' ? content.author : '');
    const[year, setYear] = useState(type === 'modify' ? content.year : '');
    const[genre, setGenre] = useState(type === 'modify' ? content.genre : '');
    const[country, setCountry] = useState(type === 'modify' ? content.country : '');
    const[pages, setPages] = useState(type === 'modify' ? content.pages : '');
    const[editor, setEditor] = useState(type === 'modify' ? content.editor : '');
    const[isbn, setIsbn] = useState(type === 'modify' ? content.isbn : '');
    const[summary, setSummary] = useState(type === 'modify' ? content.summary : '');


// write the handleSubmit function here
    const handleSubmit = (e) => {
        // empty the form
        setTitle('');
        setAuthor('');
        setYear('');
        setGenre('');
        setCountry('');
        setPages('');
        setEditor('');
        setIsbn('');
        setSummary('');

        e.preventDefault();
        const book = {
            title,
            author,
            year,
            genre,
            language,
            country,
            pages,
            editor,
            isbn,
            summary
        };
        // Show the information in a pop-up window
        alert("The book has been added to the database");
        console.log(book);
    };

    return(
        //write the form here
        <>          
            <form onSubmit={handleSubmit}>
                    <label className="field">Title:
                        <br/>
                        <input
                        type="text"
                        name="title"
                        placeholder='Insert...'
                        value={title} onChange={e => setTitle(e.target.value)} />
                    </label>
                    <label className="field">Editor:
                        <br/>
                        <input
                        type="text"
                        name="editor"
                        placeholder='Insert...'
                        value={editor} onChange={e => setEditor(e.target.value)} />
                    </label> 
                    <label className="field">Country:
                        <br/>
                        <input
                        type="text"
                        name="country"
                        placeholder='Insert...'
                        value={country} onChange={e => setCountry(e.target.value)} />
                    </label>
                    <label className="field">ISBN:
                        <br/>
                        <input
                        type="text"
                        name="isbn"
                        placeholder='Insert...'
                        value={isbn} onChange={e => setIsbn(e.target.value)} />
                    </label>
                    <label className="field">Author:
                        <br/>
                        <input
                        type="text"
                        name="author"
                        placeholder='Insert...'
                        value={author} onChange={e => setAuthor(e.target.value)} />
                    </label>
                    <label className="field">Year:
                        <br/>
                        <input
                        type="text"
                        name="year"
                        placeholder='Insert...'
                        value={year} onChange={e => setYear(e.target.value)} />
                    </label>
                    <label className="field">Pages:
                        <br/>
                        <input
                        type="text"
                        name="pages"
                        placeholder='Insert...'
                        value={pages} onChange={e => setPages(e.target.value)} />
                    </label>
                    <label className="field">Genre:
                        <br/>
                        <input
                        type="text"
                        name="genre"
                        placeholder='Insert...'
                        value={genre} onChange={e => setGenre(e.target.value)} />
                    </label>
                    <label className="field">Summary:
                        <br/>
                        <input
                        type="text"
                        name="summary"
                        placeholder='Insert...'
                        value={summary} onChange={e => setSummary(e.target.value)} />
                    </label>
                    <button type="submit">Submit</button>
            </form>
                
           
        </>
    );
}
export default BookForm;