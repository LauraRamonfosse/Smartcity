import React, { useState } from 'react';

function RoleForm(){
    const [name, setName] = useState(type === 'modify' ? content.name : '');
    const [description, setDescription] = useState(type === 'modify' ? content.description : '');

    const handleSubmit = (e) => {
        e.preventDefault();
        // Show the information in a pop-up window
        alert("The role has been added to the database");
        console.log(role);
    };

    return(
        //write the form here
        <>          
            <form onSubmit={handleSubmit}>
                    <label className="field">Name:
                        <br/>
                        <input
                        type="text"
                        name="name"
                        placeholder='Insert...'
                        value={role.name} onChange={e => setRole(e.target.value)} />
                    </label>
                    <label className="field">Description:
                        <br/>
                        <input
                        type="text"
                        name="description"
                        placeholder='Insert...'
                        value={role.description} onChange={e => setRole( e.target.value)} />
                    </label> 
                    <input type="submit" value="Submit" />
            </form>
        </>
    );  
}

export default RoleForm;