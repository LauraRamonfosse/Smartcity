import { useState } from 'react';
import '../../stylesheet/backoffice.css'

function ReviewForm({type, content}){
    const[title, setTitle] = useState(type === 'modify' ? content.title : '');
    const[book, setBook] = useState(type === 'modify' ? content.book : '');
    const[text, setText] = useState(type === 'modify' ? content.text : '');

// write the handleSubmit function here
    const handleSubmit = (e) => {
        // empty the form
        setTitle('');
        setBook('');
        setText('');

        e.preventDefault();
        const review = {
            title,
            book,
            text
        };
        // Show the information in a pop-up window
        alert("The review has been added to the database");
        console.log(review);
    };

    return(
        //write the form here
        <>          
            <form onSubmit={handleSubmit}>
                    <label className="field">Title:
                        <br/>
                        <input
                        type="text"
                        name="title"
                        placeholder='Insert...'
                        value={title} onChange={e => setTitle(e.target.value)} />
                    </label>
                    <label className="field">Book:
                        <br/>
                        <input
                        type="text"
                        name="book"
                        placeholder='Insert...'
                        value={book} onChange={e => setBook(e.target.value)} />
                    </label> 
                    <label className="field">Text:
                        <br/>
                        <input
                        type="text"
                        name="text"
                        placeholder='Insert...'
                        value={text} onChange={e => setText(e.target.value)} />
                    </label>
                    <input type="submit" value="Submit" />
            </form>
        </>
    );
}

export default ReviewForm;
