import { useState } from 'react';
import '../../stylesheet/backoffice.css'

function CommentForm({type, content}){
    const[text, setText] = useState(type === 'modify' ? content.text : '');

// write the handleSubmit function here
    const handleSubmit = (e) => {
        // empty the form
        setContent('');
        switch(type){
            case 'ADD':
                alert("The comment has been added to the database");
                break;
            case 'MODIFY':
                alert("The comment has been edited in the database");
                break;
        }
        e.preventDefault();
        const comment = {
            text
        };
        // Show the information in a pop-up window
        alert("The comment has been added to the database");
        console.log(comment);
    };

    return(
        //write the form here
        <>          
            <form onSubmit={handleSubmit}>
                    <label className="field">Text:
                        <br/>
                        <input
                        type="text"
                        name="text"
                        placeholder='Insert...'
                        value={text} onChange={e => setText(e.target.value)} />
                    </label>
                    <input type="submit" value="Submit" />
            </form>
        </>
    );
}

export default CommentForm;