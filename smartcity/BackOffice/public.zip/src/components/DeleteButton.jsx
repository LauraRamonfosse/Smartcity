import React from "react";

//write a button that delete a line from a table, that recieve the name of the table and the id of the line
function DeleteButton(/*{ table, id }*/) {
  const handleClick = () => {
    //delete the line from the table
    console.log("The line has been deleted");
    //open a pop-up window instead to inform of the success
    alert("The line has been deleted");
  };

  return (
    <>
      <button onClick={handleClick}>
        Delete
      </button>
    </>
  );
}

export default DeleteButton;
